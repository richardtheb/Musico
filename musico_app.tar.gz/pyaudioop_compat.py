"""
Compatibility module for pyaudioop which was removed in Python 3.13
This provides basic functionality needed by shazamio
"""

import numpy as np

def mul(fragment, width, factor):
    """Multiply audio fragment by factor"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data = np.frombuffer(fragment, dtype=dtype)
    result = (data * factor).astype(dtype)
    return result.tobytes()

def add(fragment1, fragment2, width):
    """Add two audio fragments"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data1 = np.frombuffer(fragment1, dtype=dtype)
    data2 = np.frombuffer(fragment2, dtype=dtype)
    result = np.clip(data1 + data2, np.iinfo(dtype).min, np.iinfo(dtype).max).astype(dtype)
    return result.tobytes()

def bias(fragment, width, bias):
    """Add bias to audio fragment"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data = np.frombuffer(fragment, dtype=dtype)
    result = np.clip(data + bias, np.iinfo(dtype).min, np.iinfo(dtype).max).astype(dtype)
    return result.tobytes()

def reverse(fragment, width):
    """Reverse audio fragment"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data = np.frombuffer(fragment, dtype=dtype)
    result = np.flip(data).astype(dtype)
    return result.tobytes()

def tomono(fragment, width, lfactor, rfactor):
    """Convert stereo to mono"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data = np.frombuffer(fragment, dtype=dtype)
    if len(data) % 2 != 0:
        raise ValueError("Fragment length must be even for stereo")
    
    left = data[::2]
    right = data[1::2]
    result = (left * lfactor + right * rfactor).astype(dtype)
    return result.tobytes()

def tostereo(fragment, width, lfactor, rfactor):
    """Convert mono to stereo"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data = np.frombuffer(fragment, dtype=dtype)
    left = (data * lfactor).astype(dtype)
    right = (data * rfactor).astype(dtype)
    result = np.empty(len(data) * 2, dtype=dtype)
    result[::2] = left
    result[1::2] = right
    return result.tobytes()

def ratecv(fragment, width, nchannels, inrate, outrate, state, weightA=1, weightB=0):
    """Rate conversion (simplified implementation)"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    data = np.frombuffer(fragment, dtype=dtype)
    
    # Simple linear interpolation for rate conversion
    if inrate == outrate:
        return data.tobytes(), state
    
    ratio = outrate / inrate
    new_length = int(len(data) * ratio)
    
    if new_length == 0:
        return b'', state
    
    # Simple linear interpolation
    indices = np.linspace(0, len(data) - 1, new_length)
    result = np.interp(indices, np.arange(len(data)), data).astype(dtype)
    
    return result.tobytes(), state

def lin2lin(fragment, width, newwidth):
    """Convert between different sample widths"""
    if width == 1:
        dtype = np.int8
    elif width == 2:
        dtype = np.int16
    elif width == 4:
        dtype = np.int32
    else:
        raise ValueError("Invalid width")
    
    if newwidth == 1:
        new_dtype = np.int8
    elif newwidth == 2:
        new_dtype = np.int16
    elif newwidth == 4:
        new_dtype = np.int32
    else:
        raise ValueError("Invalid newwidth")
    
    data = np.frombuffer(fragment, dtype=dtype)
    
    # Convert to float, scale, and convert back
    if width == 1:
        data_float = data.astype(np.float32) / 128.0
    elif width == 2:
        data_float = data.astype(np.float32) / 32768.0
    elif width == 4:
        data_float = data.astype(np.float32) / 2147483648.0
    
    if newwidth == 1:
        result = (data_float * 128.0).astype(new_dtype)
    elif newwidth == 2:
        result = (data_float * 32768.0).astype(new_dtype)
    elif newwidth == 4:
        result = (data_float * 2147483648.0).astype(new_dtype)
    
    return result.tobytes()

def ulaw2lin(fragment, width):
    """Convert u-law to linear"""
    # Simplified implementation - just return the fragment
    return fragment

def lin2ulaw(fragment, width):
    """Convert linear to u-law"""
    # Simplified implementation - just return the fragment
    return fragment

def alaw2lin(fragment, width):
    """Convert A-law to linear"""
    # Simplified implementation - just return the fragment
    return fragment

def lin2alaw(fragment, width):
    """Convert linear to A-law"""
    # Simplified implementation - just return the fragment
    return fragment
